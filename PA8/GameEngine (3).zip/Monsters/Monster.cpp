#include "Monster.h"
#include <cmath>

// write your code here
Monster::Monster(int x, int y):MapUnit(x,y){

}
Monster::~Monster(){

}
bool Monster::is_active() const{
    return is_active();
}
void Monster::recover_hp(int hp){
    hp+=1;
    return;
}
UnitType Monster::get_unit_type() const{
    return MONSTER;
}
bool Monster::is_blocked() const{
    if(MapUnit::is_valid())return true;
    else return false;
}
int Monster::attacked_by(int atk_){
    return 0;
}
string Monster::get_display_str() const{
    return SYM_EMPTY;
}
void Monster::follow(const Player &p, MapUnit *map[][MAP_SIZE]){
    return;
}
