#include "Warlock.h"

Warlock::Warlock(int x, int y) : Monster(x, y)
{
    cur_hp = max_hp = 15;
    atk = 5, def = 1;
}

//write your code here

Warlock::~Warlock(){

}
string Warlock::get_monster_str() const{
    return "W";
}
void Warlock::action(Player &p, MapUnit *map[][MAP_SIZE]){
    return;
}
